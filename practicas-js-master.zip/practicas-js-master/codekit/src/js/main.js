
// @codekit-prepend '../../bower_components/jquery/dist/jquery.js'
// @codekit-prepend '../../bower_components/cookies-js/dist/cookies.js'
// @codekit-append './cookies.js'
// @codekit-append './scroll-top2.js'
// @codekit-append './validacion-formulario.js'

function mainInit() {
  //console.log('initialize YAAAAA...');
  $('p').css('color', 'green');
}
document.addEventListener('DOMContentLoaded', mainInit);

